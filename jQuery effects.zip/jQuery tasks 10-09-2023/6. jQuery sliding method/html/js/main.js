$(document).ready(function(){
	$("button").click(function(){
		$("div").slideUp(1000, function(){
			$("div").slideDown(1000, function(){
				$("div").slideToggle(1000)
			})
		})
	});
});