$(document).ready(function(){
	$("button").click(function(){
		$("div").fadeOut(1000, function(){
			$("div").fadeIn(1000)
		});
	});
});