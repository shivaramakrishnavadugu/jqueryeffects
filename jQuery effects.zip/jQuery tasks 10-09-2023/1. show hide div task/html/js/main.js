$(document).ready(function(){
	$("button").click(function(){
		$("#divone").hide(1000, function(){
			$("#divone").show(1000)
		});
	});
});