$(document).ready(function(){
	$("button").click(function(){
		$("#para").toggle(1000);
	});
});