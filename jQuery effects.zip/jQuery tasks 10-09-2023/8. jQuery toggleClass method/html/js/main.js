$(document).ready(function(){
	$("#btn1").click(function(){
		$("div").toggleClass("divone");
	});
});

$(document).ready(function(){
	$("#btn2").click(function(){
		$("p").toggleClass("pone");
	})
});

$(document).ready(function(){
	$("#btn3").click(function(){
		$("span").toggleClass("spanone");
	})
});